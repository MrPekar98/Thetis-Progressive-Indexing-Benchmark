import os
import json
import csv
import pickle
import sys

def highest_weight(csv_table, weights):
    highest = 0
    idx = 0
    table = list()

    for row in csv_table:
        tmp_row = list()

        for column in row:
            tmp_row.append(column)

        table.append(tmp_row)

    for i in range(len(table[0])):
        sum = 0

        for j in range(len(table)):
            if table[j][i] in weights.keys():
                sum += weights[table[j][i]]

        print(sum)

        if sum > highest:
            highest = sum
            idx = i

    return idx

dir = sys.argv[1]
benchmark_name = sys.argv[2]

if not os.path.exists(dir):
    print('Query directory \'' + dir + '\' does not exist')
    exit(1)

tables = os.listdir(dir)
weights = dict()
intent = dict()
prog = 0

with open('entity_weights.json', 'r') as file:
    weights = json.load(file)

for table in tables:
    print(' ' * 100, end = '\r')
    print(str((float(prog) / len(tables)) * 100)[:5])
    prog += 1

    with open(dir + table, 'r') as file:
        reader = csv.reader(file)
        idx = highest_weight(reader, weights)
        intent[table] = idx

with open(benchmark_name + 'IntentColumnBenchmark.pickle', 'wb') as file:
    pickle.dump(intent, file)

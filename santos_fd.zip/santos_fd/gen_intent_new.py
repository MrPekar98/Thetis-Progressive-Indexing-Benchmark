import os
import json
import csv
import pickle

intent = dict()
intent['wikipage_207751.csv'] = 0
intent['wikipage_219781.csv'] = 0
intent['wikipage_236956.csv'] = 3
intent['wikipage_37750.csv'] = 0
intent['wikipage_208676.csv'] = 0
intent['wikipage_221458.csv'] = 0
intent['wikipage_208974.csv'] = 0
intent['wikipage_213901.csv'] = 0
intent['wikipage_214321.csv'] = 0
intent['wikipage_217164.csv'] = 0
intent['wikipage_217332.csv'] = 0
intent['wikipage_217987.csv'] = 0
intent['wikipage_22228.csv'] = 0
intent['wikipage_22325.csv'] = 1
intent['wikipage_224035.csv'] = 0
intent['wikipage_224605.csv'] = 0
intent['wikipage_227091.csv'] = 0
intent['wikipage_231849.csv'] = 0
intent['wikipage_237327.csv'] = 1
intent['wikipage_241581.csv'] = 0
intent['wikipage_24787.csv'] = 0
intent['wikipage_24800.csv'] = 1
intent['wikipage_25198.csv'] = 1
intent['wikipage_3245.csv'] = 1
intent['wikipage_35180.csv'] = 0
intent['wikipage_38711.csv'] = 0
intent['wikipage_39080.csv'] = 1
intent['wikipage_39142.csv'] = 0
intent['wikipage_39515.csv'] = 0
intent['wikipage_39901.csv'] = 0
intent['wikipage_48101.csv'] = 2
intent['wikipage_4851.csv'] = 1
intent['wikipage_51148.csv'] = 0
intent['wikipage_53524.csv'] = 0
intent['wikipage_53803.csv'] = 0
intent['wikipage_57244.csv'] = 0
intent['wikipage_57821.csv'] = 0
intent['wikipage_58234.csv'] = 0
intent['wikipage_60695.csv'] = 0
intent['wikipage_62440.csv'] = 0
intent['wikipage_62638.csv'] = 0
intent['wikipage_70914.csv'] = 0
intent['wikipage_71264.csv'] = 0
intent['wikipage_71865.csv'] = 1
intent['wikipage_76929.csv'] = 1
intent['wikipage_7798.csv'] = 0
intent['wikipage_78653.csv'] = 0
intent['wikipage_91337.csv'] = 0
intent['wikipage_93504.csv'] = 0
intent['wikipage_998.csv'] = 0

with open('wikitablesIntentColumnBenchmark.pickle', 'wb') as file:
    pickle.dump(intent, file)

import os
import json
import csv
import pickle
import sys

dir = sys.argv[1]
benchmark_name = sys.argv[3]

if not os.path.exists(dir):
    print('Query directory \'' + dir + '\' does not exist')
    exit(1)

queries = os.listdir(dir)
table_dir = sys.argv[2]

if not os.path.exists(table_dir):
    print('Table directory \'' + table_dir + '\' does not exist')
    exit(1)

tables = os.listdir(table_dir)
union = dict()

for query in queries:
    union[query] = tables

with open(benchmark_name + 'UnionBenchmark.pickle', 'wb') as file:
    pickle.dump(union, file)

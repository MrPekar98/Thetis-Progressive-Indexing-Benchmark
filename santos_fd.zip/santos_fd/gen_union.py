import os
import json
import csv
import pickle

dir = '../../../benchmark/wikitables_benchmark/query/'
queries = os.listdir(dir)
tables = os.listdir('../../../benchmark/wikitables_benchmark/dataLake/')
union = dict()

for query in queries:
    union[query] = tables

with open('wikitablesUnionBenchmark.pickle', 'wb') as file:
    pickle.dump(union, file)
